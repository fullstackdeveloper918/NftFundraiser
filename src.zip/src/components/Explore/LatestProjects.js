import React, { Component } from 'react';
import AuctionsOne from '../Auctions/AuctionsOne';



const LatestProject = () => {


    return (
        <>
            <AuctionsOne />
        </>
    );
}


export default LatestProject;